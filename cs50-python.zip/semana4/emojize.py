import emoji

entrada = input("Digite algo com um código emoji (ex: :thumbs_up:): ")
print(emoji.emojize(entrada))