resposta = input("O que você quer dizer? ").strip().lower()
if resposta == "42" or resposta == "forty-two" or resposta == "forty two":
    print("Yes")
else:
    print("No")