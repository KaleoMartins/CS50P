entrada = input("Digite algo: ")
print(entrada.replace(" ", "..."))